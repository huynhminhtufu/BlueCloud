self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "165c2c6013e998b9264a",
    "url": "/static/js/main.165c2c60.chunk.js"
  },
  {
    "revision": "bfeb1ec26e7abc1249db",
    "url": "/static/js/1.bfeb1ec2.chunk.js"
  },
  {
    "revision": "165c2c6013e998b9264a",
    "url": "/static/css/main.9479d2a6.chunk.css"
  },
  {
    "revision": "92c0671403f556d15afae91998c45d6b",
    "url": "/index.html"
  }
];