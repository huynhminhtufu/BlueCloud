-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_demo
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `signer_doctypes`
--

DROP TABLE IF EXISTS `signer_doctypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signer_doctypes` (
  `DocTypeID` int(11) NOT NULL AUTO_INCREMENT,
  `DocType` varchar(150) DEFAULT NULL,
  `Expires` bit(1) DEFAULT NULL,
  `States` varchar(50) DEFAULT NULL,
  `FileName` varchar(20) DEFAULT NULL,
  `ExpRef` varchar(20) DEFAULT NULL,
  `RatingCredit` int(11) DEFAULT NULL,
  PRIMARY KEY (`DocTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signer_doctypes`
--

LOCK TABLES `signer_doctypes` WRITE;
/*!40000 ALTER TABLE `signer_doctypes` DISABLE KEYS */;
INSERT INTO `signer_doctypes` VALUES (1,'Notary Commision','','US','com','notaryexp',0),(2,'Attorney Bar Card','','MA,DE,GA','attorney',NULL,0),(3,'License Title Producer','','VA,MD,DC','titleprod','ltpexp',0),(4,'Independant Escrow','','IN, VA','indesc',NULL,0),(5,'Drivers License','\0','US','dl',NULL,0),(6,'W9','\0','US','w9',NULL,0),(7,'NNA Certification','','US','certif',NULL,0),(8,'Background Check','','US','breport','glbexp',0),(9,'E & O Insurance','','US','errorsom','eoexp',0),(10,'Bond','','US','bond','bondexp',0),(11,'References','\0','US','ref',NULL,0),(12,'Fidelity Release Form','\0','US','fidre',NULL,0),(13,'Misc','\0','US','misc',NULL,0),(14,'TRID Self Certification','\0','US','trid',NULL,0),(15,'Closing Agent License','','MN','titlecom',NULL,0);
/*!40000 ALTER TABLE `signer_doctypes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:53
