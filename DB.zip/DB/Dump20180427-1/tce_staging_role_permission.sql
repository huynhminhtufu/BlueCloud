-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_staging
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permission` (
  `RoleId` int(11) NOT NULL AUTO_INCREMENT,
  `RoleName` varchar(100) NOT NULL,
  `Type` varchar(15) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `RoleAndPermission` bit(1) NOT NULL DEFAULT b'0',
  `ClientManagement` bit(1) NOT NULL DEFAULT b'0',
  `ClientPipeline` bit(1) NOT NULL DEFAULT b'0',
  `Chatting` bit(1) NOT NULL DEFAULT b'0',
  `VendorManagement` bit(1) NOT NULL DEFAULT b'0',
  `VendorPipeline` bit(1) NOT NULL DEFAULT b'0',
  `InternalUserManagement` bit(1) NOT NULL DEFAULT b'0',
  `AssignVendor` bit(1) NOT NULL DEFAULT b'0',
  `VendorClassification` bit(1) NOT NULL DEFAULT b'0',
  `Reporting` bit(1) NOT NULL DEFAULT b'0',
  `AddViewOrder` bit(1) NOT NULL DEFAULT b'0',
  `VendorRatingSetting` bit(1) NOT NULL DEFAULT b'0',
  `FeeApproval` bit(1) NOT NULL DEFAULT b'0',
  `VendorApproval` bit(1) NOT NULL DEFAULT b'0',
  `ServiceConfigurationApproval` bit(1) NOT NULL DEFAULT b'0',
  `VendorCredentialsDocumentApproval` bit(1) NOT NULL DEFAULT b'0',
  `SignedDocumentApproval` bit(1) NOT NULL DEFAULT b'0',
  `ChangeFeeOnClosedOrders` bit(1) NOT NULL DEFAULT b'0',
  `DisableNewOrders` bit(1) NOT NULL DEFAULT b'0',
  `AutoOrders` bit(1) NOT NULL DEFAULT b'0',
  `IssueApproval` bit(1) NOT NULL DEFAULT b'0',
  `IssueReporting` bit(1) NOT NULL DEFAULT b'0',
  `UserProfileSetting` bit(1) NOT NULL DEFAULT b'0',
  `FeeRequest` bit(1) NOT NULL DEFAULT b'0',
  `ClientProfile` bit(1) NOT NULL DEFAULT b'0',
  `ServiceConfiguration` bit(1) NOT NULL DEFAULT b'0',
  `ManageCustomer` bit(1) NOT NULL DEFAULT b'0',
  `ManageBranch` bit(1) NOT NULL DEFAULT b'0',
  `ManageAgent` bit(1) NOT NULL DEFAULT b'0',
  `ViewAllOrders` bit(1) NOT NULL DEFAULT b'0',
  `AddOrder` bit(1) NOT NULL DEFAULT b'0',
  `ManageOrderDetails` bit(1) NOT NULL DEFAULT b'0',
  `VendorDoNotUse` bit(1) NOT NULL DEFAULT b'0',
  `ViewVendorDetails` bit(1) NOT NULL DEFAULT b'0',
  `Tools` bit(1) NOT NULL DEFAULT b'0',
  `UserManagement` bit(1) NOT NULL DEFAULT b'0',
  `ContentManagement` bit(1) NOT NULL DEFAULT b'0',
  `TrainingAndTesting` bit(1) NOT NULL DEFAULT b'0',
  `Accounting` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
INSERT INTO `role_permission` VALUES (1,'Admin','Staff',NULL,'','','','','','','','','','','','','','','','','','','','','','','','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','','','',''),(2,'Operational Manager','Staff',NULL,'','','','','','','','','','','','','','','','','','','','','','','','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','','\0','\0','\0'),(3,'Scheduler','Staff',NULL,'\0','','','\0','','','\0','','\0','\0','','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','','','','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0'),(4,'Status Rep','Staff','Status Representative','\0','','','\0','','','\0','\0','\0','\0','','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','','','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0'),(5,'Client','Client','Admin','','\0','\0','','\0','\0','\0','\0','\0','','\0','','','','\0','\0','\0','\0','\0','\0','','\0','','\0','','','','','','','','','','','','\0','\0','\0','\0'),(6,'Branch','Client','Manager','','\0','\0','','\0','\0','\0','\0','\0','\0','\0','\0','','','\0','\0','\0','\0','\0','\0','','\0','','\0','\0','\0','','','','','','','','','','\0','\0','\0','\0'),(7,'Agent','Client','Scheduler & Status Rep','','\0','\0','','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','','\0','\0','\0','\0','\0','\0','\0','\0','','\0','','','\0','\0','\0','\0'),(8,'Vendor','Vendor',NULL,'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0'),(9,'Content Manager','Staff','Content Manager','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','','\0','\0'),(10,'Training Manager','Staff','Training Manager','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','','\0'),(11,'Accounting Manager','Staff','Accounting Manager','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',''),(12,'Quality Control','Staff','Quality Control','','','','','','','','','','','','','','','','','','','','','','','','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','','\0','\0','\0');
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:17
