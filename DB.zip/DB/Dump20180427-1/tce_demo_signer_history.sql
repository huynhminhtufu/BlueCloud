-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_demo
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `signer_history`
--

DROP TABLE IF EXISTS `signer_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signer_history` (
  `HistoryId` int(11) NOT NULL AUTO_INCREMENT,
  `OrderId` int(11) DEFAULT NULL,
  `SignerId` int(11) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `HistoryDate` datetime DEFAULT NULL,
  PRIMARY KEY (`HistoryId`),
  KEY `orderid_signer_history_idx` (`OrderId`),
  KEY `signerid_signer_history_idx` (`SignerId`),
  CONSTRAINT `orderid_signer_history` FOREIGN KEY (`OrderId`) REFERENCES `order` (`OrderId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `signerid_signer_history` FOREIGN KEY (`SignerId`) REFERENCES `signer` (`SignerId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signer_history`
--

LOCK TABLES `signer_history` WRITE;
/*!40000 ALTER TABLE `signer_history` DISABLE KEYS */;
INSERT INTO `signer_history` VALUES (1,1,1,'Assigned','2018-03-22 13:54:04'),(2,2,5,'Assigned','2018-03-23 11:40:38'),(3,6,7,'Assigned','2018-03-23 13:06:05'),(4,8,2,'Assigned','2018-03-23 13:08:02'),(5,8,2,'Removed','2018-03-23 13:09:14'),(6,8,3,'Removed','2018-03-23 13:11:35'),(7,6,7,'Removed','2018-03-23 13:29:24'),(8,10,10,'Assigned','2018-03-26 03:41:34'),(9,13,14,'Assigned','2018-03-26 03:47:56'),(10,13,14,'Removed','2018-03-26 03:48:09'),(11,13,7,'Assigned','2018-03-26 03:49:23'),(12,13,7,'Removed','2018-03-26 03:50:04'),(13,13,8,'Assigned','2018-03-26 03:50:26'),(14,13,8,'Removed','2018-03-26 03:50:57'),(15,13,10,'Assigned','2018-03-26 03:53:57'),(16,15,2,'Assigned','2018-03-26 13:59:02'),(17,19,10,'Assigned','2018-03-26 17:19:50'),(18,20,14,'Assigned','2018-03-26 17:29:00'),(19,20,14,'Removed','2018-03-26 17:30:11'),(20,20,7,'Assigned','2018-03-26 17:39:26'),(21,21,7,'Assigned','2018-03-27 06:56:21'),(22,17,4,'Assigned','2018-03-27 07:24:26'),(23,17,4,'Removed','2018-03-27 07:24:33'),(24,21,7,'Removed','2018-03-27 07:24:44'),(25,2,5,'Removed','2018-03-27 07:37:18'),(26,17,5,'Assigned','2018-03-27 07:40:40'),(27,2,5,'Assigned','2018-03-27 07:41:48'),(28,17,5,'Removed','2018-03-27 07:42:22'),(29,2,5,'Removed','2018-03-27 07:47:46'),(30,17,5,'Assigned','2018-03-27 07:48:31'),(31,2,5,'Assigned','2018-03-27 07:49:09'),(32,17,5,'Removed','2018-03-27 07:49:36'),(33,2,5,'Removed','2018-03-27 07:55:56'),(34,9,14,'Assigned','2018-03-27 15:13:03'),(35,14,14,'Assigned','2018-03-27 15:16:35'),(36,14,14,'Removed','2018-03-27 15:19:52'),(37,14,10,'Assigned','2018-03-27 15:25:43'),(38,1,1,'Removed','2018-03-27 15:33:09'),(39,1,1,'Assigned','2018-03-27 15:34:09'),(40,1,1,'Removed','2018-03-27 15:34:22'),(41,10,10,'Removed','2018-03-27 15:45:08'),(42,10,7,'Assigned','2018-03-27 16:05:07'),(43,11,7,'Assigned','2018-03-27 16:27:08'),(44,11,7,'Removed','2018-03-27 16:31:39'),(45,23,7,'Assigned','2018-03-27 17:03:35'),(46,13,10,'Removed','2018-03-27 18:23:07'),(47,9,14,'Removed','2018-03-28 00:33:00'),(48,14,10,'Removed','2018-03-28 02:30:06'),(49,21,13,'Assigned','2018-03-28 17:17:06'),(50,10,7,'Removed','2018-03-28 18:10:43'),(51,49,13,'Assigned','2018-03-30 11:24:12'),(52,46,7,'Removed','2018-03-30 12:01:22'),(53,56,7,'Removed','2018-04-02 03:08:43'),(54,14,10,'Assigned','2018-04-02 18:58:14'),(55,14,10,'Removed','2018-04-02 18:58:34'),(56,14,14,'Assigned','2018-04-02 18:58:45'),(57,14,14,'Removed','2018-04-03 02:43:01'),(58,56,7,'Removed','2018-04-03 17:47:54'),(59,65,7,'Assigned','2018-04-03 20:48:12'),(60,56,7,'Assigned','2018-04-04 08:53:06'),(61,59,5,'Assigned','2018-04-04 12:19:33'),(62,1,1,'Removed','2018-04-04 13:24:02'),(63,67,2,'Removed','2018-04-04 15:05:42'),(64,67,2,'Assigned','2018-04-04 15:11:18'),(65,67,2,'Removed','2018-04-04 15:24:37'),(66,67,2,'Removed','2018-04-04 17:50:39'),(67,46,14,'Assigned','2018-04-04 22:45:21'),(68,14,10,'Assigned','2018-04-04 22:56:14'),(69,14,10,'Removed','2018-04-04 23:05:40'),(70,14,NULL,'Removed','2018-04-04 23:05:40'),(71,14,NULL,'Removed','2018-04-04 23:05:40'),(72,56,7,'Removed','2018-04-04 23:11:26'),(73,56,7,'Assigned','2018-04-05 03:17:28'),(74,56,7,'Removed','2018-04-05 06:43:44'),(75,56,7,'Assigned','2018-04-05 09:04:28'),(76,56,7,'Removed','2018-04-05 09:25:21'),(77,71,7,'Assigned','2018-04-06 10:12:52'),(78,71,7,'Removed','2018-04-06 10:14:48'),(79,71,7,'Assigned','2018-04-06 10:15:08'),(80,72,7,'Assigned','2018-04-06 10:21:36'),(81,72,7,'Removed','2018-04-06 10:22:03'),(82,71,7,'Removed','2018-04-06 10:35:42'),(83,70,7,'Assigned','2018-04-06 10:46:42'),(84,13,7,'Assigned','2018-04-06 10:46:57'),(85,71,33,'Assigned','2018-04-06 11:16:18'),(86,71,33,'Removed','2018-04-06 11:19:52'),(87,71,33,'Assigned','2018-04-06 11:22:23'),(88,71,33,'Removed','2018-04-06 11:23:32'),(89,2,3,'Assigned','2018-04-06 15:35:54'),(90,17,3,'Assigned','2018-04-06 15:36:06'),(91,71,33,'Removed','2018-04-09 05:31:50'),(92,71,33,'Removed','2018-04-09 06:50:33'),(93,71,33,'Assigned','2018-04-09 06:55:09'),(94,71,33,'Removed','2018-04-09 08:18:58'),(95,71,33,'Assigned','2018-04-09 08:27:00'),(96,71,33,'Removed','2018-04-09 09:57:14'),(97,69,33,'Assigned','2018-04-09 10:14:07'),(98,55,33,'Assigned','2018-04-09 10:16:32'),(99,71,33,'Assigned','2018-04-09 11:53:51'),(100,69,33,'Removed','2018-04-09 11:55:52'),(101,71,33,'Removed','2018-04-09 12:04:26'),(102,76,33,'Removed','2018-04-09 12:10:02'),(103,71,7,'Assigned','2018-04-09 12:44:49'),(104,2,3,'Removed','2018-04-09 14:22:06'),(105,85,2,'Assigned','2018-04-09 14:34:35'),(106,85,2,'Removed','2018-04-09 14:56:37'),(107,85,2,'Assigned','2018-04-09 14:58:07'),(108,85,2,'Removed','2018-04-09 15:26:23'),(109,85,2,'Removed','2018-04-09 15:36:31'),(110,85,2,'Assigned','2018-04-09 15:36:38'),(111,71,7,'Removed','2018-04-10 07:45:07'),(112,71,7,'Assigned','2018-04-10 07:49:39'),(113,71,7,'Removed','2018-04-10 07:49:52'),(114,77,33,'Removed','2018-04-10 07:53:47'),(115,77,33,'Assigned','2018-04-10 08:02:22'),(116,77,33,'Removed','2018-04-10 09:27:25'),(117,77,33,'Assigned','2018-04-10 09:40:02'),(118,96,33,'Removed','2018-04-11 04:22:50'),(119,77,33,'Removed','2018-04-11 04:26:36'),(120,55,33,'Removed','2018-04-11 04:27:07'),(121,55,33,'Assigned','2018-04-11 04:27:54'),(122,55,33,'Removed','2018-04-11 04:28:03'),(123,55,33,'Assigned','2018-04-11 04:28:31'),(124,55,33,'Removed','2018-04-11 04:28:40'),(125,55,33,'Assigned','2018-04-11 04:29:26'),(126,55,33,'Removed','2018-04-11 04:29:35'),(127,55,33,'Assigned','2018-04-11 04:30:03'),(128,55,33,'Removed','2018-04-11 04:30:11'),(129,55,33,'Assigned','2018-04-11 04:30:30'),(130,55,33,'Removed','2018-04-11 04:30:45'),(131,55,33,'Assigned','2018-04-11 04:31:29'),(132,55,33,'Removed','2018-04-11 04:31:44'),(133,17,3,'Removed','2018-04-11 07:19:56'),(134,55,33,'Assigned','2018-04-11 08:28:05'),(135,55,33,'Removed','2018-04-11 08:28:19'),(136,55,33,'Assigned','2018-04-11 08:28:37'),(137,98,33,'Assigned','2018-04-11 08:32:46'),(138,98,33,'Removed','2018-04-11 08:35:02'),(139,98,33,'Assigned','2018-04-11 08:38:11'),(140,98,33,'Removed','2018-04-11 08:38:21'),(141,100,33,'Assigned','2018-04-11 09:29:40'),(142,100,33,'Removed','2018-04-11 09:33:25'),(143,100,33,'Assigned','2018-04-11 09:35:29'),(144,100,33,'Removed','2018-04-11 09:35:34'),(145,100,33,'Removed','2018-04-11 09:43:26'),(146,100,33,'Assigned','2018-04-11 09:44:25'),(147,100,33,'Removed','2018-04-11 09:45:00'),(148,100,33,'Assigned','2018-04-11 09:45:56'),(149,65,7,'Removed','2018-04-11 12:45:46'),(150,102,3,'Removed','2018-04-11 13:05:37'),(151,102,3,'Removed','2018-04-11 13:23:56'),(152,102,5,'Assigned','2018-04-11 13:24:29'),(153,102,5,'Removed','2018-04-11 13:28:34'),(154,102,3,'Removed','2018-04-11 13:32:18'),(155,102,5,'Assigned','2018-04-11 13:32:43'),(156,98,33,'Assigned','2018-04-12 02:07:39'),(157,101,33,'Removed','2018-04-12 02:09:11'),(158,101,33,'Assigned','2018-04-12 02:10:58'),(159,101,33,'Removed','2018-04-12 02:11:58'),(160,71,33,'Assigned','2018-04-13 16:07:57'),(161,68,33,'Assigned','2018-04-13 16:09:58'),(162,108,33,'Removed','2018-04-13 17:05:26');
/*!40000 ALTER TABLE `signer_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:32
