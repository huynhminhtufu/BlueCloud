-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_demo
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order_special_instructions`
--

DROP TABLE IF EXISTS `order_special_instructions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_special_instructions` (
  `SpecialInsId` int(11) NOT NULL AUTO_INCREMENT,
  `OrderId` int(11) DEFAULT NULL,
  `Instructions1` varchar(250) DEFAULT NULL,
  `Permanently1` varchar(1) DEFAULT 'N',
  `Instructions2` varchar(250) DEFAULT NULL,
  `Permanently2` varchar(1) DEFAULT 'N',
  `Instructions3` varchar(250) DEFAULT NULL,
  `Permanently3` varchar(1) DEFAULT 'N',
  `Instructions4` varchar(250) DEFAULT NULL,
  `Permanently4` varchar(1) DEFAULT 'N',
  `Instructions5` varchar(250) DEFAULT NULL,
  `Permanently5` varchar(1) DEFAULT 'N',
  `Instructions6` varchar(250) DEFAULT NULL,
  `Permanently6` varchar(1) DEFAULT 'N',
  `Instructions7` varchar(250) DEFAULT NULL,
  `Permanently7` varchar(1) DEFAULT 'N',
  `Instructions8` varchar(250) DEFAULT NULL,
  `Permanently8` varchar(1) DEFAULT 'N',
  `Instructions9` varchar(250) DEFAULT NULL,
  `Permanently9` varchar(1) DEFAULT 'N',
  `Instructions10` varchar(250) DEFAULT NULL,
  `Permanently10` varchar(1) DEFAULT 'N',
  PRIMARY KEY (`SpecialInsId`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_special_instructions`
--

LOCK TABLES `order_special_instructions` WRITE;
/*!40000 ALTER TABLE `order_special_instructions` DISABLE KEYS */;
INSERT INTO `order_special_instructions` VALUES (1,1,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(2,2,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(3,3,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(4,4,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(5,5,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(6,6,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(7,7,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(8,8,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(9,9,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(10,10,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(11,11,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(12,12,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(13,13,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(14,14,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(15,15,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(16,16,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(17,17,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(18,18,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(19,19,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(20,20,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(21,21,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(22,22,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(23,23,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(24,24,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(25,25,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(26,26,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(27,27,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(28,28,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(29,29,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(30,30,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(31,31,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(32,32,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(33,33,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(34,34,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(35,35,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(36,36,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(37,37,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(38,38,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(39,39,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(40,40,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(41,41,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(42,42,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(43,43,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(44,44,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(45,45,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(46,46,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(47,47,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(48,48,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(49,49,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(50,50,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(51,51,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(52,52,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(53,53,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(54,54,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(55,55,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(56,56,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(57,57,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(58,58,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(59,59,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(60,60,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(61,61,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(62,62,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(63,63,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(64,64,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(65,65,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(66,66,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(67,67,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(68,68,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(69,69,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(70,70,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(71,71,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(72,72,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(73,73,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(74,74,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(75,75,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(76,76,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(77,77,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(78,78,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(79,79,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(80,80,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(81,81,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(82,82,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(83,83,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(84,84,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(85,85,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(86,86,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(87,87,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(88,88,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(89,89,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(90,90,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(91,91,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(92,92,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(93,93,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(94,94,NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N',NULL,'N'),(95,95,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(96,96,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(97,97,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(98,98,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(99,99,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(100,100,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(101,101,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(102,102,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(103,103,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(104,104,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(105,105,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(106,106,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(107,107,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N'),(108,108,'','N','','N','','N','','N','','N','','N','','N','','N','','N','','N');
/*!40000 ALTER TABLE `order_special_instructions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:41
