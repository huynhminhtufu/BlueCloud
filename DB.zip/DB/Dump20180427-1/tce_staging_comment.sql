-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_staging
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `CommentID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(250) DEFAULT NULL,
  `CreatedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` int(11) NOT NULL,
  `ParentID` int(11) DEFAULT NULL,
  `TypeID` int(11) NOT NULL,
  `OwnerID` int(11) NOT NULL,
  `IsPrivate` bit(1) NOT NULL DEFAULT b'0',
  `TenantID` int(11) DEFAULT NULL,
  PRIMARY KEY (`CommentID`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 COMMENT='Table order comments';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'add comment','2018-03-23 20:09:33',92,NULL,4,1,'\0',NULL),(2,'','2018-03-23 14:04:09',40,NULL,2,7,'\0',NULL),(3,'Test note here.  I want to write a note.','2018-03-26 12:54:35',19,NULL,1,18,'\0',NULL),(4,'Here is a private note.','2018-03-26 12:55:31',19,NULL,1,18,'',NULL),(5,'He is really good and wants to make money','2018-03-26 13:35:05',110,NULL,2,8,'\0',NULL),(6,'More money!','2018-03-27 16:44:29',40,NULL,2,10,'\0',NULL),(7,'this is a test ','2018-03-27 10:02:07',81,NULL,1,23,'\0',NULL),(8,'Test1 AF','2018-03-27 05:31:23',1,NULL,1,9,'\0',NULL),(9,'test','2018-03-27 07:13:18',2,NULL,1,14,'\0',NULL),(10,'another test','2018-03-27 07:13:28',2,NULL,1,14,'\0',NULL),(11,'test2','2018-03-27 07:18:26',1,NULL,1,9,'\0',NULL),(12,'test 3','2018-03-27 07:18:34',1,NULL,1,9,'\0',NULL),(13,'test4','2018-03-27 07:18:47',1,NULL,1,9,'',NULL),(14,'Good','2018-03-28 01:50:57',90,NULL,1,21,'\0',NULL),(15,'Quite good','2018-03-28 01:51:08',90,NULL,1,21,'\0',NULL),(16,'Perfect','2018-03-28 01:52:41',90,NULL,1,21,'',NULL),(17,'Perfect','2018-03-28 01:55:11',90,NULL,1,21,'\0',NULL),(18,'Good','2018-03-28 02:44:43',2,NULL,1,14,'\0',NULL),(19,'Perfect','2018-03-28 02:45:06',2,NULL,1,14,'',NULL),(20,'Test','2018-03-28 17:18:57',36,NULL,2,11,'\0',NULL),(21,'Tuc is nice and deserves extra','2018-03-28 13:48:21',118,NULL,2,12,'\0',NULL),(22,'','2018-03-28 17:50:58',40,NULL,2,13,'\0',NULL),(23,'Please','2018-03-28 17:55:45',40,NULL,2,14,'\0',NULL),(24,'Please assist with this','2018-03-28 13:59:07',118,NULL,2,14,'\0',NULL),(25,'hello','2018-03-29 08:50:15',90,NULL,1,42,'\0',NULL),(26,'I got a problem with the documents','2018-03-29 08:50:30',90,NULL,1,42,'\0',NULL),(27,'ok','2018-03-29 09:15:56',105,NULL,1,42,'\0',NULL),(28,'Hi all','2018-03-29 09:19:56',2,NULL,1,14,'\0',NULL),(29,'Hi all','2018-03-29 09:19:56',2,NULL,1,14,'\0',NULL),(30,'Hi all','2018-03-29 09:19:56',2,NULL,1,14,'\0',NULL),(31,'Hello all','2018-03-29 09:20:20',2,NULL,1,14,'\0',NULL),(32,'Hello all','2018-03-29 09:20:20',2,NULL,1,14,'\0',NULL),(33,'asdasdasd','2018-03-29 09:21:39',2,NULL,1,14,'',NULL),(34,'This is a private message','2018-03-29 09:24:14',2,NULL,1,14,'',NULL),(35,'This is a private message','2018-03-29 09:24:13',2,NULL,1,14,'',NULL),(36,'This is a private message','2018-03-29 09:24:13',2,NULL,1,14,'',NULL),(37,'This is a private message','2018-03-29 09:24:13',2,NULL,1,14,'',NULL),(38,'This is another private message','2018-03-29 09:24:41',2,NULL,1,14,'',NULL),(39,'This is another private message','2018-03-29 09:24:41',2,NULL,1,14,'',NULL),(40,'This is another private message','2018-03-29 09:24:41',2,NULL,1,14,'',NULL),(41,'This is another private message','2018-03-29 09:24:41',2,NULL,1,14,'',NULL),(42,'This is another private message','2018-03-29 09:24:42',2,NULL,1,14,'',NULL),(43,'This is another private message','2018-03-29 09:24:41',2,NULL,1,14,'',NULL),(44,'Goodbye!!!','2018-03-29 09:25:31',2,NULL,1,14,'\0',NULL),(45,'dsdfsdf','2018-03-29 09:33:37',81,NULL,1,15,'\0',NULL),(46,'asdasdasdas','2018-03-29 09:33:41',81,NULL,1,15,'\0',NULL),(47,'toantc test','2018-03-29 09:33:50',81,NULL,1,15,'',NULL),(48,'test','2018-03-29 17:21:22',120,NULL,2,15,'\0',NULL),(49,'test reply','2018-03-29 17:30:09',31,NULL,2,15,'\0',NULL),(50,'Need mo money','2018-03-30 08:05:05',118,NULL,2,16,'\0',NULL),(51,'Need to pay car off','2018-03-30 08:06:14',118,NULL,2,17,'\0',NULL),(52,'Don\'t like this guy','2018-03-30 08:08:59',25,NULL,2,17,'\0',NULL),(53,'I like this guy','2018-03-30 08:09:11',25,NULL,2,16,'\0',NULL),(54,'Additional Details','2018-03-30 18:33:37',40,NULL,2,18,'\0',NULL),(55,'Additional Details','2018-03-30 18:40:09',40,NULL,2,19,'\0',NULL),(56,'','2018-04-02 03:09:31',40,NULL,2,20,'\0',NULL),(57,'','2018-04-03 02:56:18',40,NULL,2,21,'\0',NULL),(58,'add comment','2018-04-03 16:45:26',86,NULL,2,22,'\0',NULL),(59,'add note','2018-04-03 16:57:01',86,NULL,2,24,'\0',NULL),(60,'new Note','2018-04-03 16:10:50',8,NULL,1,63,'\0',NULL),(61,'next note','2018-04-03 16:11:07',8,NULL,1,63,'',NULL),(62,'testing','2018-04-04 07:44:58',81,NULL,2,25,'\0',NULL),(63,'sounds good','2018-04-04 10:58:46',8,NULL,2,28,'\0',NULL),(64,'we have time, let\'s keep trying','2018-04-04 11:07:48',8,NULL,2,29,'\0',NULL),(65,'You have a better offer pending','2018-04-04 11:29:12',8,NULL,2,31,'\0',NULL),(66,'OK','2018-04-04 11:29:33',8,NULL,2,30,'\0',NULL),(67,'this is another test, but it is private','2018-04-04 11:34:31',81,NULL,1,23,'',NULL),(68,'testing note','2018-04-05 09:25:13',31,NULL,1,49,'\0',NULL),(69,'Additional Details','2018-04-05 02:59:33',40,NULL,2,32,'\0',NULL),(70,'Additional Details','2018-04-05 03:03:27',40,NULL,2,33,'\0',NULL),(71,'','2018-04-06 04:03:00',40,NULL,2,35,'\0',NULL),(72,'','2018-04-06 10:23:09',40,NULL,2,36,'\0',NULL),(73,'add comment request fee','2018-04-06 17:43:10',86,NULL,2,38,'\0',NULL),(74,'The pay is too low. ','2018-04-09 02:35:16',140,NULL,2,39,'\0',NULL),(75,'Additional Details','2018-04-09 02:36:08',140,NULL,2,40,'\0',NULL),(76,'Additional Details','2018-04-09 02:57:34',140,NULL,2,41,'\0',NULL),(77,'Additional Details','2018-04-09 03:22:27',140,NULL,2,42,'\0',NULL),(78,'Additional Details','2018-04-09 04:13:31',140,NULL,2,43,'\0',NULL),(79,'Additional Details','2018-04-09 04:17:05',140,NULL,2,44,'\0',NULL),(80,'Additional Details','2018-04-09 05:32:34',140,NULL,2,45,'\0',NULL),(81,'','2018-04-09 05:40:18',140,NULL,2,46,'\0',NULL),(82,'Additional Details','2018-04-09 08:24:03',140,NULL,2,47,'\0',NULL),(83,'','2018-04-09 10:08:13',140,NULL,2,48,'\0',NULL),(84,'','2018-04-09 10:10:29',140,NULL,2,49,'\0',NULL),(85,'','2018-04-09 10:10:52',140,NULL,2,50,'\0',NULL),(86,'','2018-04-09 10:12:57',140,NULL,2,51,'\0',NULL),(87,'','2018-04-09 11:45:12',140,NULL,2,52,'\0',NULL),(88,'','2018-04-09 11:50:13',140,NULL,2,53,'\0',NULL),(89,'','2018-04-09 12:36:15',140,NULL,2,54,'\0',NULL),(90,'','2018-04-09 12:42:20',140,NULL,2,55,'\0',NULL),(91,'','2018-04-09 15:28:04',35,NULL,2,56,'\0',NULL),(92,'','2018-04-10 07:46:44',40,NULL,2,57,'\0',NULL),(93,'','2018-04-10 07:50:42',40,NULL,2,58,'\0',NULL),(94,'','2018-04-10 07:52:26',140,NULL,2,59,'\0',NULL),(95,'','2018-04-10 07:53:15',140,NULL,2,60,'\0',NULL),(96,'','2018-04-10 07:59:24',140,NULL,2,61,'\0',NULL),(97,'','2018-04-11 04:12:29',140,NULL,2,62,'\0',NULL),(98,'','2018-04-11 04:12:48',140,NULL,2,63,'\0',NULL),(99,'Hello','2018-04-11 14:28:09',90,NULL,1,17,'\0',NULL),(100,'','2018-04-11 09:37:34',140,NULL,2,64,'\0',NULL),(101,'','2018-04-11 09:54:50',140,NULL,2,65,'\0',NULL),(102,'','2018-04-11 09:56:37',140,NULL,2,66,'\0',NULL),(103,'test vendor with error','2018-04-11 08:13:34',81,NULL,4,2,'\0',NULL),(104,'best option','2018-04-11 08:47:43',130,NULL,4,3,'\0',NULL),(105,'no one else available','2018-04-11 08:53:00',130,NULL,4,4,'\0',NULL),(106,'again','2018-04-11 09:05:51',130,NULL,4,5,'\0',NULL),(107,'test','2018-04-11 09:24:12',130,NULL,4,6,'\0',NULL),(108,'test','2018-04-11 09:28:47',130,NULL,4,7,'\0',NULL),(109,'test','2018-04-11 09:29:27',8,NULL,4,7,'\0',NULL),(110,'test','2018-04-11 09:32:35',130,NULL,4,8,'\0',NULL),(111,'test','2018-04-11 09:33:18',8,NULL,4,8,'\0',NULL),(112,'','2018-04-13 15:39:03',140,NULL,2,67,'\0',NULL),(113,'','2018-04-16 15:54:18',40,NULL,2,68,'\0',NULL),(114,'Add note','2018-04-24 15:19:51',1,NULL,1,190,'\0',NULL),(115,'','2018-04-24 15:44:38',40,NULL,2,75,'\0',NULL),(116,'test','2018-04-24 15:50:52',40,NULL,2,76,'\0',NULL),(117,'Vi Create note','2018-04-24 16:29:00',1,NULL,1,189,'\0',NULL),(118,'','2018-04-26 14:07:03',40,NULL,2,77,'\0',NULL),(119,'','2018-04-26 14:07:27',40,NULL,2,78,'\0',NULL),(120,'','2018-04-26 14:11:20',40,NULL,2,79,'\0',NULL),(121,'','2018-04-26 14:12:47',40,NULL,2,80,'\0',NULL),(122,'','2018-04-26 14:16:47',40,NULL,2,81,'\0',NULL),(123,'This is good vendor','2018-04-27 13:36:47',86,NULL,4,9,'\0',NULL),(124,'','2018-04-27 13:54:41',40,NULL,2,83,'\0',NULL),(125,'this is good vendor','2018-04-27 14:03:27',86,NULL,4,10,'\0',NULL),(126,'OK','2018-04-27 15:02:47',86,NULL,4,11,'\0',NULL),(127,'add comment','2018-04-27 15:06:27',86,NULL,2,85,'\0',NULL),(128,'request fee','2018-04-27 15:21:41',86,NULL,2,86,'\0',NULL),(129,'abc','2018-04-27 15:37:12',86,NULL,2,88,'\0',NULL),(130,'xfvg','2018-04-27 15:49:31',1,NULL,2,88,'\0',NULL);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:22
