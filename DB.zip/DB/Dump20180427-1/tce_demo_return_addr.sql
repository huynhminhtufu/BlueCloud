-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_demo
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `return_addr`
--

DROP TABLE IF EXISTS `return_addr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `return_addr` (
  `RaId` int(11) NOT NULL AUTO_INCREMENT,
  `BrokerId` int(11) DEFAULT NULL,
  `Department` varchar(30) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Suite` varchar(10) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `State` varchar(2) DEFAULT NULL,
  `Zip` varchar(5) DEFAULT NULL,
  `DefaultAddr` varchar(1) DEFAULT NULL,
  `BranchId` int(11) DEFAULT NULL,
  PRIMARY KEY (`RaId`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_addr`
--

LOCK TABLES `return_addr` WRITE;
/*!40000 ALTER TABLE `return_addr` DISABLE KEYS */;
INSERT INTO `return_addr` VALUES (1,1,NULL,'6111 W. Plano Parkway','3000','Houston','TX','75093','Y',NULL),(2,2,NULL,'15061 springdale street',NULL,'Huntington Beach','CA','92649','Y',NULL),(3,3,NULL,'15061 springdale street',NULL,'Huntington Beach','CA','92649','Y',NULL),(4,4,NULL,'5346 Portland St.',NULL,'Columbus','OH','43235','Y',NULL),(5,5,NULL,'15061 springdale street',NULL,'Huntington Beach','AL','92649','Y',NULL),(6,6,NULL,'MSC3ARP, Box 30001',NULL,'Las Cruces','NM','88003','Y',NULL),(7,7,NULL,'123 Main',NULL,'Any','FL','32086','Y',NULL),(8,8,NULL,'2155 Old Moultrie Rd.',NULL,'St. Augustine','FL','32086','Y',NULL),(9,9,NULL,'123 Main',NULL,'Any','FL','32086','Y',NULL),(10,10,NULL,'15061 Springdale',NULL,'Huntington Beach','CA','12345','Y',NULL),(11,11,NULL,'1212 Harbor Blvd.',NULL,'Huntington Beach','CA','92646','Y',NULL),(12,12,NULL,'15061 Test St',NULL,'Huntington Beach','CA','92646','Y',NULL),(13,13,NULL,'1212 Bogus Ave',NULL,'Bovine','FL','32086','Y',NULL),(14,14,NULL,'100 Main St',NULL,'Bovine','CA','92648','Y',NULL),(15,15,NULL,'6310 Nancy Ridge Drive','Ste 103','San Diego','CA','92121','Y',NULL),(16,16,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(17,17,NULL,'1395 loma ave',NULL,'Long Beach','CA','90804','Y',NULL),(18,18,NULL,'555 Main st',NULL,'St Augustine','FL','32086','Y',NULL),(19,19,NULL,'1212 Bogus Ave',NULL,'Huntington Beach','CA','92646','Y',NULL),(20,20,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(21,21,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(22,22,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(23,23,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(24,24,NULL,'1212 Bogus Ave',NULL,'St. Augustine','FL','32086','Y',NULL),(25,25,NULL,'6111 W. Plano Parkway','3000','Houston','TX','75096','Y',NULL),(26,26,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(27,27,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(28,28,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(29,29,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(30,30,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(31,31,NULL,'1212 Bogus Ave',NULL,'Huntington Beach','CA','92646','Y',NULL),(32,32,NULL,'100 Main St',NULL,'Huntington Beach','CA','92648','Y',NULL),(33,33,NULL,'1212 Harbor Blvd.',NULL,'Costa Mesa','CA','92626','Y',NULL),(34,40,NULL,NULL,NULL,'Huntington Beach','CA','92649','Y',NULL),(35,41,NULL,NULL,NULL,'Huntington Beach','CA','92649','N',NULL),(36,41,'Other department','452 Other Street',NULL,'Beverly Hills','CA','90210','Y',NULL),(37,46,NULL,NULL,'3000','Houston','TX','75096','Y',NULL),(38,50,NULL,NULL,'3000','Houston','TX','75093','Y',NULL),(39,51,NULL,NULL,NULL,'St. Augustine','FL','32086','Y',NULL),(40,52,NULL,NULL,NULL,'St. Augustine','FL','32086','Y',NULL),(41,53,NULL,NULL,NULL,'St. Augustine','FL','32086','Y',NULL),(42,59,NULL,NULL,NULL,'St. Augustine','FL','32086','Y',NULL),(43,61,NULL,NULL,NULL,'St. Augustine','FL','32086','Y',NULL),(44,62,NULL,NULL,NULL,'St. Augustine','FL','32086','Y',NULL);
/*!40000 ALTER TABLE `return_addr` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:49
