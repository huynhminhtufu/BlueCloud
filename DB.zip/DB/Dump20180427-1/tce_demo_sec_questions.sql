-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_demo
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sec_questions`
--

DROP TABLE IF EXISTS `sec_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_questions` (
  `ChalId` int(11) NOT NULL,
  `Question` varchar(100) DEFAULT NULL,
  `Example` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ChalId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_questions`
--

LOCK TABLES `sec_questions` WRITE;
/*!40000 ALTER TABLE `sec_questions` DISABLE KEYS */;
INSERT INTO `sec_questions` VALUES (1,'What is the middle name of your oldest child?','Bruce'),(2,'What was your childhood nickname?','Kid'),(3,'In what city or town was your first job?','Mountain View'),(4,'What was the name of your favorite cartoon character as a child?','Jerry'),(5,'What is your youngest sibling’s birthday month and year (use full month and year)?','Jan 2000'),(6,'What is the first name of the best man/maid of honor at your wedding?','John'),(7,'What street did you live on in the third grade?','Gateway'),(8,'What is your youngest sibling’s middle name?','Paul'),(9,'In what city or town did your mother and father meet?','Montclair'),(10,'What is the name of your favorite childhood friend?','Smith'),(11,'What is your oldest sibling’s birthday month and year (use full month and year)?','Dec 1990'),(12,'What is your maternal grandmother’s maiden name?','Jenna'),(13,'What is the name of your favorite childhood author?','Conan Doyle'),(14,'While in high school, what was the name of your favorite music group/singer?','Maroon 5'),(15,'What school did you attend for sixth grade?','Montclair School'),(16,'What was the name of the place your wedding reception was held?','Montclair Event'),(17,'What is your oldest sibling’s middle name?','Jenny'),(18,'What is the name of your first childhood pet?','Pull'),(19,'What is the name of a college you applied to but didn’t attend?','Montclair College'),(20,'What is your oldest cousin’s first and last name?','John Smith');
/*!40000 ALTER TABLE `sec_questions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:33
