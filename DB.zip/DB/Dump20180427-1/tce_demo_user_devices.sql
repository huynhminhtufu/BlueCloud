-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_demo
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_devices`
--

DROP TABLE IF EXISTS `user_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_devices` (
  `UserDeviceId` int(11) NOT NULL AUTO_INCREMENT,
  `UsersId` int(11) NOT NULL,
  `DeviceId` varchar(200) NOT NULL,
  `EndpointArn` varchar(1000) DEFAULT NULL,
  `IsSignedIn` bit(1) DEFAULT NULL,
  PRIMARY KEY (`UserDeviceId`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_devices`
--

LOCK TABLES `user_devices` WRITE;
/*!40000 ALTER TABLE `user_devices` DISABLE KEYS */;
INSERT INTO `user_devices` VALUES (2,40,'31f495b36351d298a767dd4810ff0c8937cb95de0d1bf752ee51faeb66f9147c','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/0bfa3a94-98a3-3d96-9b75-bf132b1dc325',''),(4,40,'bac53e54fec600a2b5cf7abaa0df04e6d325b4ad66281d8085fdfeb83f38fd75','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/9663a630-c30e-3b5e-86ea-6d1545445913',''),(5,40,'f6c5d1c4086b2be13113cf27ff8314ab309f4ebcae30399ca1526e9c2b614ee8','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/cc259035-4b9e-30ef-8ada-16d1cdb87e55',''),(6,40,'4e9898de40edb2f160562004382562e3108ec021acba60796ea6d7a4691cae9e','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/00795488-26b1-37fe-b31f-2f63ff95ed07',''),(7,34,'7857c41e9835f296316948ff0fab8b6915bcef594117235852a360b0bf9939b2','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/37132c13-4252-3ec3-85b4-be5ad98b5830',''),(8,44,'7857c41e9835f296316948ff0fab8b6915bcef594117235852a360b0bf9939b2',NULL,''),(9,38,'7857c41e9835f296316948ff0fab8b6915bcef594117235852a360b0bf9939b2','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/37132c13-4252-3ec3-85b4-be5ad98b5830',''),(10,43,'7857c41e9835f296316948ff0fab8b6915bcef594117235852a360b0bf9939b2','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/37132c13-4252-3ec3-85b4-be5ad98b5830',''),(11,40,'7857c41e9835f296316948ff0fab8b6915bcef594117235852a360b0bf9939b2','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/37132c13-4252-3ec3-85b4-be5ad98b5830',''),(12,40,'84d726fe0d29e0f3d4e428f4acd375b64d49f4ee9780b721d2dd7d402bd3ec68','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/6d608d17-7bc7-3ca1-8586-ca319a7b8566',''),(13,40,'9baeae3adb0db642fe5382551f03c337de69f1576fb1f2e849e3d0454b27f9d3','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/cdf051a8-54e4-3182-89f7-cb7576165efe',''),(14,40,'f398686420ef8a99b2fdcca6b5f7948d45685931f29065c41c8558473feed805','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/15318617-aa67-3f75-a9eb-0b1471b877ea',''),(17,40,'04c0c8c6f78d540f9b70e90dd2e5ae524ba6bef63d901648d34573eff19b9242','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/5631930e-1077-3d3d-816b-ebd398524dbf',''),(20,40,'2a4ce9ae7136f849e4f05d73355be5d1c20876ed9379b8220767a8ef4b8377d6','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/2855144b-c504-3ade-a97f-b201d2da61eb',''),(21,40,'0de68533e08fc0383b41c2e250fda1cbeacec844bc9354d5ffe4ba9814d674a9','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/b43d9862-1baf-3639-980f-9cf556de40c1',''),(22,40,'f4240200b06e0b3cc5418720f9d713554b8d227c7e3129b9ee3df54c46bdc1c0','arn:aws:sns:us-east-1:841040368837:endpoint/APNS_SANDBOX/CE-Mobile/afd6c6ef-6a4f-3333-acf6-52e1f73827ac',''),(23,40,'e34691b735a95b849ae202818affa86496449ff826ad71affe807262fe566489','arn:aws:sns:us-east-1:841040368837:endpoint/APNS_SANDBOX/CE-Mobile/5722f1c0-82e3-35f4-be83-b9658266b874',''),(24,140,'5c45b282fdaa3b2945c24cd9b580c2f6fe74fb0ba4362d8b0f589ace18656dfb','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/9414ea0b-6bc0-390b-be1b-7d5c4303849c',''),(25,140,'3eff555820976771d086de64568a12877c7c8141febde2c1bffbea09a12bc2dd','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/bc260697-ddaa-3cee-b446-6b38ddbe8f7f',''),(26,140,'92f924a4295764adc31b84407f9a071d5a868ab9a5f425f97b8e5c9529b648ad','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/698582e0-d240-3f13-9809-279bf6c94b73',''),(27,40,'2e39acf2de348758a440766017d374dfef58668217187994135fa0cfa64f1f78',NULL,''),(28,40,'8092f5f6626184242a3b63b75734b05147caec2fa2f0bc6cb0ebcbe55b087ff9','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/9444cc27-d90a-3ace-8117-ea3b07f4f221',''),(29,40,'',NULL,''),(30,140,'6ed97d83d3deb8402357346e6f93a3a1d0dffa300f3830a83fe1075bfd7a3607','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/a408683e-ef90-3fc8-8848-28e4ac208857',''),(31,44,'41f5e81c49ae970a02393f34d0a57179e831925b0ec5e2c27e0d6e6bd7943182',NULL,''),(32,40,'41f5e81c49ae970a02393f34d0a57179e831925b0ec5e2c27e0d6e6bd7943182','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/89e60a05-1f47-361e-83d6-8c23bea97268',''),(33,140,'c2487f6bc58b0b1a754c75e82622e5dd0215cafd42f4c5177dbc68b3c0f65de4','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/bae1c708-65fc-37fc-9a1e-bbcd5a9d6af0',''),(34,140,'e14d9a6cc7528637450d2a76371a8c21d433d4723f35dccc962b436b0a7089ca','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/5f8834ac-e187-3cdf-ad00-a78e8aded84f',''),(35,140,'497c130476989be3bc5ae30146f75aed1bc4d23e0d00f5fb082dcba51363121b','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/50762940-cb6b-322d-afff-2baf0d4c0cf2',''),(36,140,'9a2819a3a2ac34d0e6864f7f460087b712b7bddaa266afd85aa33d252ab791a9','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/1106377a-8329-335e-b5fa-58c3ddeb27ab',''),(37,140,'33c0e9bb05d87eadd9e2eda16a62f79398c085fe4036159045d5003e26e0ba2f','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/4fc87313-bb43-3fd4-bab0-7dfd0351bc71',''),(38,140,'7dbdb2b645db4a196d58bbd59a8536c145931283c7095b06f756d6f028d53131','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/968774c0-e5d9-3ca9-8af9-59243e8b45bc',''),(39,140,'3404aa2f8fa8f0f5683cf4b4861952de9a140ff78c448a79a2dae9684ddd3a7b','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/19949208-1c9a-338f-8156-c1cd1158533a',''),(40,140,'1f5fed1dec8392433cd2aae90ec6771a665f86532e71b212453e978ef560b914','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/1e83d41d-1b62-391a-80c4-7395e4fe0f96',''),(41,140,'4b2104d765a8231c3ebd49e3d84270cf4d30a5249b16685df03d3169d244b5b1','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/e0e7b68c-e8f1-3573-b940-d1ffd8a1b116',''),(42,140,'336b08cbc9c1eacbacbe5ca856843543c2ad6047739ea37ad8d6d0455b72f8d6','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/060ef1a3-c197-36bb-9280-d6238fe584a0',''),(43,140,'a5fc25076da62e6feec395baf88b6e09850a848fd43543e99675b7ac8069f039','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/bf8fb56e-f0ed-3b52-996c-9f46d5805a38',''),(44,40,'f5f324c28e3c912e7ded89104f2471982f3fe9de1902fb63347239229ed2775d',NULL,'\0'),(45,140,'bc3ae5ba162756df7d1500e9ae7746d4635b31a29fe29904a361f7391152266b','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/29857e69-d8cf-3e86-aa80-1adcf5827cb5',''),(46,140,'',NULL,''),(47,140,'026812d3a93d4de6c94b982c573e304e37479afa39b29cc229425b753ce09f09','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/6e3ebd4b-2868-3350-90aa-d02a61d6f57b',''),(48,40,'3365eb0fb48ff1a1e554f8a757dc78cc695ab732b5091406fbb270ed5d6443ef',NULL,''),(49,40,'42f3a46eac5fed90640e20b4f9ba00b9ce2bc25b72e2c8268da5b2df7edb0970',NULL,''),(50,140,'0eaff7afa0587e29e4c002b909d9bd8ecbf784a92874477279d10cc1ebf6b60f','arn:aws:sns:us-east-1:841040368837:endpoint/APNS/CE-Production/ea41c585-ae37-350f-bff2-181f90e2edb0','');
/*!40000 ALTER TABLE `user_devices` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:37
