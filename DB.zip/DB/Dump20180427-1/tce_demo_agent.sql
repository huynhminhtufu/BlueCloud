-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_demo
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agent`
--

DROP TABLE IF EXISTS `agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent` (
  `AgentId` int(11) NOT NULL AUTO_INCREMENT,
  `TenantId` int(11) DEFAULT NULL,
  `Ext` varchar(5) DEFAULT NULL,
  `Fax` varchar(10) DEFAULT NULL,
  `Email` varchar(70) DEFAULT NULL,
  `AfterhoursPhone` varchar(10) DEFAULT NULL,
  `Inactive` bit(1) DEFAULT NULL,
  `BranchID` int(11) DEFAULT NULL,
  `Direct` varchar(15) DEFAULT NULL,
  `ViewAll` bit(1) DEFAULT NULL,
  `BrokerId` int(11) DEFAULT NULL,
  `FullName` varchar(150) DEFAULT NULL,
  `NeedResetPassword` bit(1) DEFAULT b'0',
  PRIMARY KEY (`AgentId`),
  UNIQUE KEY `AgentId_UNIQUE` (`AgentId`),
  KEY `TenantId_idx` (`TenantId`),
  KEY `brokerid_agent_idx` (`BrokerId`),
  KEY `branch_agent_idx` (`BranchID`),
  CONSTRAINT `TenantId_agent` FOREIGN KEY (`TenantId`) REFERENCES `tenant` (`TenantId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `branch_agent` FOREIGN KEY (`BranchID`) REFERENCES `branches` (`BranchID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `brokerid_agent` FOREIGN KEY (`BrokerId`) REFERENCES `broker` (`BrokerID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent`
--

LOCK TABLES `agent` WRITE;
/*!40000 ALTER TABLE `agent` DISABLE KEYS */;
INSERT INTO `agent` VALUES (1,1,'','','annv2@fsoft.com.vn','','\0',NULL,'','\0',10,'Agent of Branch FPT3','\0'),(2,1,'','','hienlt13@fsoft.com.vn','','\0',NULL,'','\0',1,'Helen Swift','\0'),(3,1,'','','huent6@fsoft.com.vn','','\0',NULL,'','\0',2,'AgentCompany','\0'),(4,1,'','','hangntq@fsoft.com.vn','','\0',NULL,'','\0',37,'HangAgent','\0'),(5,1,'','','huent6@fsoft.com.vn','0145475454','\0',NULL,'','\0',36,'hue_agent','\0'),(6,1,'','','joe@agent.com','','\0',NULL,'','',40,'joe agent test','\0'),(7,1,'','','agent2@test.com','','\0',NULL,'','\0',2,'agent 2','\0'),(8,1,'','','testagent3@gmail.com','','\0',NULL,'','\0',2,'test agent 3@','\0'),(9,1,'43','2453453453','mittt@fsoft.com.vn','4546464645','\0',NULL,'3214234234','',37,'MI Tong_Agent','\0'),(10,1,'302','6558987755','rtest@test.com','6148885544','\0',NULL,'6145073255','',19,'Rob Testyman','\0'),(11,1,'302','6665555444','testy@testemail.com','8885554444','\0',NULL,'8885554444','',19,'Rob William','\0'),(12,1,'','','huent6@fsoft.com.vn','','\0',NULL,'','',45,'FPTAgent','\0'),(13,1,'252','','agentman@agent.com','7458584554','\0',NULL,'6155556688','',46,'Jana Banhagel','\0'),(14,1,'','','bagent@gmail.com','','\0',NULL,'','\0',31,'Bill Agent','\0'),(15,1,'854','6516549846','jennie@jennie.com','6565651651','\0',NULL,'9566516516','',33,'Tommy Tutone','\0'),(16,1,'','','mjacobson@theclosingexchange.com','','\0',NULL,'4584584588','',8,'Michelle Jacobson','\0'),(17,1,'','','mjacobson@theclosingexchange.com','','\0',NULL,'4564584588','',51,'Michelle Jacobson','\0'),(18,1,'','','mjacobson@notarydirect.com','','\0',NULL,'','\0',51,'Meesh Jacobson','\0'),(19,1,'123','','sseitzinger@theclosingexchange.com','','\0',NULL,'8888888888','',9,'SSAgent','\0'),(20,1,'','','mjacobson@notarydirect.com','','\0',NULL,'','',59,'Michelle Parcell','\0'),(21,1,'','','mjacobson@theclosingexchange.com','','\0',NULL,'','',25,'Meesh Parcell','\0'),(22,1,'1231','','pavaso01@adb.com','1322132131','\0',NULL,'3131313131','',64,'Hana Agent','\0'),(23,1,'','','Testagent4@mail.com','','\0',NULL,'','\0',2,'Testagent4@mail.com','\0'),(24,1,'','','testAgent5@mail.com','','\0',NULL,'','\0',64,'testAgent5@mail.com','\0'),(25,1,'','','pavaso01@adb.com','','\0',NULL,'','\0',64,'1Hana Agent','\0');
/*!40000 ALTER TABLE `agent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:43
