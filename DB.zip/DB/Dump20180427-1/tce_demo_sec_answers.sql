-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 10.133.28.217    Database: tce_demo
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sec_answers`
--

DROP TABLE IF EXISTS `sec_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sec_answers` (
  `AnswerId` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11) DEFAULT NULL,
  `ChalId1` int(11) DEFAULT NULL,
  `Answer1` varchar(250) DEFAULT NULL,
  `ChalId2` int(11) DEFAULT NULL,
  `Answer2` varchar(250) DEFAULT NULL,
  `ChalId3` int(11) DEFAULT NULL,
  `Answer3` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`AnswerId`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sec_answers`
--

LOCK TABLES `sec_answers` WRITE;
/*!40000 ALTER TABLE `sec_answers` DISABLE KEYS */;
INSERT INTO `sec_answers` VALUES (1,84,7,'1',6,'1',11,'1'),(2,85,1,'abc',2,'abc',3,'abc'),(3,87,4,'1',10,'1',15,'1'),(4,89,1,'abc',3,'abc',2,'abc'),(5,90,1,'abc',2,'abc',3,'abc'),(6,94,1,'None',2,'None',3,'None'),(7,95,2,'None',6,'None',8,'None'),(8,96,1,'taylor',7,'wilshire',3,'seal beach'),(9,101,2,'Lunmi',3,'Hanoi',18,'Jack'),(10,102,9,'1',13,'1',5,'1'),(11,104,7,'1',10,'1',6,'1'),(12,106,4,'milo',9,'milo',13,'milo'),(13,107,2,'Lunmi',3,'Hanoi',18,'Jack'),(14,108,12,'milo',16,'milo',17,'milo'),(15,111,3,'ionia',8,'regina',1,'rae'),(16,112,7,'1',11,'1',14,'1'),(17,113,13,'milo',11,'milo',9,'milo'),(18,114,6,'milo',9,'milo',8,'milo'),(19,115,6,'milo',11,'milo',14,'milo'),(20,116,10,'1',15,'1',13,'1'),(21,121,13,'Asimov',10,'Dean',7,'Wilshire'),(22,122,10,'dasd',11,'dasd',6,'das'),(23,123,1,'1',2,'1',3,'1'),(24,124,1,'1',2,'1',4,'1'),(25,125,2,'Lunmi',3,'Hanoi',18,'Jack'),(26,127,10,'1',11,'1',12,'1'),(27,128,4,'asdf',10,'adsf',12,'asdf'),(28,138,15,'fitz',18,'blackie',6,'alma'),(29,139,17,'None',18,'None',19,'None'),(30,140,9,'1',11,'1',6,'1'),(31,141,1,'1',6,'1',11,'1'),(32,142,4,'1',9,'1',13,'1'),(33,143,1,'1',4,'1',10,'1'),(34,144,2,'bob',3,'chicago',8,'susie'),(35,145,1,'bob',3,'del',7,'man'),(36,148,1,'bob',2,'mom',7,'street'),(37,352,12,'bib',1,'bob',9,'there'),(38,353,1,'1',3,'1',4,'1');
/*!40000 ALTER TABLE `sec_answers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-27 16:53:39
