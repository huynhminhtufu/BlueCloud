self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "5f99bfbd243a58d8ea44",
    "url": "/static/js/main.5f99bfbd.chunk.js"
  },
  {
    "revision": "f68dcc1a0c0c6e129be0",
    "url": "/static/js/1.f68dcc1a.chunk.js"
  },
  {
    "revision": "5f99bfbd243a58d8ea44",
    "url": "/static/css/main.a72ee9bd.chunk.css"
  },
  {
    "revision": "e1b21d64cd7230237bf6abb1b34cb7de",
    "url": "/index.html"
  }
];