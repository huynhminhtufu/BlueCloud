self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "7f0de90edbd6fccc1c75",
    "url": "/static/js/main.7f0de90e.chunk.js"
  },
  {
    "revision": "bfeb1ec26e7abc1249db",
    "url": "/static/js/1.bfeb1ec2.chunk.js"
  },
  {
    "revision": "7f0de90edbd6fccc1c75",
    "url": "/static/css/main.9479d2a6.chunk.css"
  },
  {
    "revision": "82801ef4d6f88217f596b9a370a56279",
    "url": "/index.html"
  }
];